document.addEventListener("DOMContentLoaded", () => {
  const filterSelect = document.getElementById("filter");
  const sortSelect = document.getElementById("sort");
  const productContainer = document.getElementById("products-container");
  
  // Filter Products by Tag
  const filterProducts = () => {
    const filterValue = filterSelect.value.toLowerCase();
    document.querySelectorAll(".product-item").forEach((item) => {
      const tags = item.dataset.tags.toLowerCase();
      if (!filterValue || tags.includes(filterValue)) {
        item.style.display = "block";
        item.style.animation = "fadeIn 0.3s forwards";
      } else {
        item.style.animation = "fadeOut 0.3s forwards";
        setTimeout(() => (item.style.display = "none"), 300);
      }
    });
  };

  // Sort Products by Name or Price
  const sortProducts = () => {
    const sortValue = sortSelect.value;
    const sortedProducts = Array.from(productContainer.children).sort((a, b) => {
      const aValue = sortValue.includes("name")
        ? a.querySelector(".product-title").innerText.toLowerCase()
        : parseFloat(a.querySelector(".product-price").dataset.price);
      const bValue = sortValue.includes("name")
        ? b.querySelector(".product-title").innerText.toLowerCase()
        : parseFloat(b.querySelector(".product-price").dataset.price);

      return sortValue.endsWith("asc") ? (aValue > bValue ? 1 : -1) : (aValue < bValue ? 1 : -1);
    });

    // Re-render products with fade animation
    productContainer.style.opacity = "0";
    setTimeout(() => {
      productContainer.innerHTML = "";
      sortedProducts.forEach((item) => productContainer.appendChild(item));
      productContainer.style.opacity = "1";
    }, 300);
  };

  // Quick View Modal
  const createQuickViewModal = (product) => {
    const modal = document.createElement("div");
    modal.className = "quick-view-modal";
    modal.innerHTML = `
      <div class="modal-content">
        <span class="close-btn">&times;</span>
        <img src="${product.image}" alt="${product.title}" class="modal-image" />
        <h3>${product.title}</h3>
        <p class="modal-price">${product.price}</p>
        <p class="modal-description">${product.description}</p>
      </div>
    `;

    // Close Modal Logic
    modal.querySelector(".close-btn").addEventListener("click", () => {
      modal.style.animation = "fadeOut 0.3s forwards";
      setTimeout(() => modal.remove(), 300);
    });

    document.body.appendChild(modal);
    modal.style.animation = "fadeIn 0.3s forwards";
  };

  // Attach Events
  filterSelect.addEventListener("change", filterProducts);
  sortSelect.addEventListener("change", sortProducts);
  document.querySelectorAll(".quick-view-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const product = {
        title: btn.dataset.title,
        image: btn.dataset.image,
        price: btn.dataset.price,
        description: btn.dataset.description,
      };
      createQuickViewModal(product);
    });
  });
});
